// import axios from 'axios'

// export default () => {
//   const localData = sessionStorage.getItem('token');
//   if (localData !== '' && localData) {
//     const ztData = JSON.parse(localData);
//     axios.defaults.headers.common['access-token'] = ztData.token;
//   }
// }